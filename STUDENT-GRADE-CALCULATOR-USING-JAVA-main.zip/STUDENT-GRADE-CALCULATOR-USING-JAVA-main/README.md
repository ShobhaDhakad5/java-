# STUDENT-GRADE-CALCULATOR-USING-JAVA
student grade calculator 
in this project i do the following steps -
input : take marks obtained out of 100 in each subject
calculate total marks :sum up the marks obtained in all subjects.    
calculate average percentage : divide the total marks by the total number of subject to get the average percentage.       
grade calculation : assign grades based on the average percentage achieved .   

display results : show the total marks average and the corresponding grade to the user               
